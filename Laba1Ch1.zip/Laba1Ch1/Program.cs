﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laba1Ch1
{
    class Program
    {
        static void Main(string[] args)
        {
           
            Random rand = new Random();
            int[][] arr = new int[4][];
            arr[0] = new int[5];
            arr[1] = new int[5];
            arr[2] = new int[5];
            arr[3] = new int[5];
            for (int i = 0; i < 5; i++)
            {
                arr[0][i] = rand.Next(-10, 30);
                arr[1][i] = rand.Next(-10, 30);  
                arr[2][i] = rand.Next(-10, 30);
                arr[3][i] = rand.Next(-10, 30);
            }
            Console.WriteLine("№1\n В двумерном целочисленном массиве размером 4 строки, 5 столбцов поменяйте местами столбцы, симметричные относительно середины массива (вертикальной линии).\n");

            Console.WriteLine("Первоначальная матрица:");
            Show(arr);
            SwapDiagonal(arr);
            Console.WriteLine("\n\nПреобразованая матрица:");
            Show(arr);

            Console.ReadKey();
        }
        public static void Show(int[][] arr)
        {
            foreach (var i in arr)
            {
                Console.WriteLine();
                foreach (var j in i)
                {
                    Console.Write(" {0}", j);
                }
            }
        }

        public static void SwapDiagonal(int[][] arr)
        {
            
            for (int i = 0; i < arr.Length/2; i++)
            {
                for (int j = 0; j < arr[i].Length; j++)
                {
                    
                        int temp = arr[arr.Length - i - 1][j];
                        arr[arr.Length - i - 1][j] = arr[i][j];
                        arr[i][j] = temp;
                   
                    
                }
            }
        }
    }
}
