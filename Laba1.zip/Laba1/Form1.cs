﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static public string Drob(double numeric)
        {
            string result = "";
            bool otr = false;

            if (numeric < 0)
            {
                otr = true;
                numeric = numeric * (-1);
            }

            int ind = numeric.ToString().IndexOf(',');

            if (ind == -1)
                return numeric.ToString();

            ulong cel = ulong.Parse(numeric.ToString().Substring(0, ind));
            ulong chisl = ulong.Parse(numeric.ToString().Remove(0, ind + 1));
            ulong znam = 1;

            for (int i = 0; i < chisl.ToString().Length; i++)
                znam *= 10;

            for (ulong i = 2; i < znam; i++)
            {
                if (chisl % i == 0 && znam % i == 0)
                {
                    chisl /= i;
                    znam /= i;
                    i = 1;
                }
            }

            result = cel.ToString() + "(" +  chisl.ToString() + "/" + znam.ToString() + ")";

            if (otr)
            {
                result = "-" + result;
            }

            return result;
        }

        /*static public string Period(double numeric) 
        {
            string result = "";
            bool otr = false;

            if (numeric < 0)
            {
                otr = true;
                numeric = numeric * (-1);
            }

            int ind = numeric.ToString().IndexOf(',');

            if (ind == -1)
                return numeric.ToString();

            ulong cel = ulong.Parse(numeric.ToString().Substring(0, ind));
            ulong chisl = ulong.Parse(numeric.ToString().Remove(0, ind + 1));
            ulong znam = 1;

            for (int i = 0; i < chisl.ToString().Length; i++)
                znam *= 10;
            ulong prznam = znam - 1;
            for (ulong i = 2; i < prznam; i++)
            {
                if (chisl % i == 0 && prznam % i == 0)
                {
                    chisl /= i;
                    prznam /= i;
                    i = 1;
                }
            }

            result = cel.ToString() + "(" + chisl.ToString() + "/" + prznam.ToString() + ")";

            if (otr)
            {
                result = "-" + result;
            }

            return result;
        }*/
        static public string Period(double numeric)
        {
            string result = "";
            bool otr = false;

            if (numeric < 0)
            {
                otr = true;
                numeric = numeric * (-1);
            }

            int ind = numeric.ToString().IndexOf(',');

            if (ind == -1)
                return numeric.ToString();

            ulong cel = ulong.Parse(numeric.ToString().Substring(0, ind));
            ulong chisl = ulong.Parse(numeric.ToString().Remove(0, ind + 1));
            ulong znam = 1;

            for (int i = 0; i < chisl.ToString().Length; i++)
                znam *= 10;
            ulong prznam = znam - 1;
            for (ulong i = 2; i < prznam; i++)
            {
                if (chisl % i == 0 && prznam % i == 0)
                {
                    chisl /= i;
                    prznam /= i;
                    i = 1;
                }
            }

            result = cel.ToString() + "(" + chisl.ToString() + "/" + prznam.ToString() + ")";

            if (otr)
            {
                result = "-" + result;
            }

            return result;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
           label7.Text = Drob(Convert.ToDouble(textBox3.Text));
        }
        private void Button3_Click(object sender, EventArgs e)
        {
            label7.Text = Period(Convert.ToDouble(textBox4.Text));
        }

        static public string Drob (int chel ,double chisl, double znamn)
        {
            string result = "";
            result = (chel +(chisl / znamn)).ToString();
            return result;
        }
        static public string Period(int chel, double chisl, double znamn)
        {
            string result = "";
            double[] arr = new double [1];
            double modulo = chisl % znamn;
            int counter = 1;
            while (modulo != 0)
            {
                //if (arr[modulo - 1] != 0) break;
            }
            result = (chel + (chisl / znamn)).ToString();
           
            return result;
        }
        private void Button2_Click(object sender, EventArgs e)
        {
            label8.Text = Drob(Convert.ToInt32(textBox5.Text), Convert.ToDouble(textBox1.Text), Convert.ToDouble(textBox2.Text));
        }
        private void Button4_Click(object sender, EventArgs e)
        {
            label12.Text = Drob(Convert.ToInt32(textBox5.Text), Convert.ToDouble(textBox1.Text), Convert.ToDouble(textBox2.Text));
        }
    }
}
